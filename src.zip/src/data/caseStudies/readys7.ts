import type { CaseStudyContent } from './types';

export const readys7CaseStudy: CaseStudyContent = {
  projectLabel: 'Ready’s7',
  description:
    '통합 검색 Redis Cache 적용으로 반복 DB 직접 조회를 줄이고, 데이터 변경 후 오래된 검색 결과가 남지 않도록 무효화 기준을 설계한 백엔드 Case Study입니다.',
  sections: [
    {
      number: '01',
      id: 'overview',
      title: '프로젝트 개요',
      navTitle: '프로젝트 개요',
      navSubtitle: '서비스 소개',
      lead: '클라이언트가 프로젝트를 등록하고,\n개발자가 탐색과 제안을 통해\n협업 기회를 만드는 플랫폼입니다.',
      content: [
        {
          type: 'hero',
          label: '서비스 소개',
          paragraphs: [
            '클라이언트는 필요한 개발 프로젝트를 등록하고, 개발자는 통합 검색을 통해 조건에 맞는 프로젝트와 관련 정보를 탐색한 뒤 제안서를 제출할 수 있습니다.',
            '클라이언트는 전달된 제안과 개발자 정보를 확인한 뒤, 채팅으로 프로젝트 내용을 조율합니다. 협업 경험은 리뷰로 남겨 개발자 정보를 확인할 때 참고할 수 있도록 구성했습니다.',
          ],
          scope: ['통합 검색', '프로젝트 등록', '제안서 제출·확인', '채팅·리뷰'],
          visualSrc: '/readys7-images/readys7-overview-hero.png',
          visualAlt: '클라이언트와 개발자를 연결하는 Ready’s7 매칭 플랫폼 3D 일러스트레이션',
        },
        {
          type: 'cards',
          columns: 4,
          items: [
            { label: '통합 검색·탐색', text: '프로젝트·개발자·카테고리·기술스택을\n하나의 통합 검색에서 조회할 수 있습니다.' },
            { label: '프로젝트 등록', text: '클라이언트는 필요한 개발 프로젝트와\n요구 조건을 등록할 수 있습니다.' },
            { label: '제안서 제출·확인', text: '개발자는 프로젝트에 제안서를 제출하고, 클라이언트는 전달된 제안과 개발자 정보를 확인합니다.' },
            { label: '채팅·리뷰', text: '채팅을 통해 프로젝트 조건과 협업 내용을 조율하고, 협업 경험은 리뷰로 남길 수 있습니다.' },
          ],
        },
      ],
    },
    {
      number: '02',
      id: 'problem',
      title: '문제 정의',
      navTitle: '문제 정의',
      navSubtitle: '반복 검색과 결과 최신성',
      lead: '같은 검색 조건의 요청이 반복될 때마다 검색 과정을 다시 수행했고,\nCache 적용 후에는 변경된 데이터가 기존 검색 결과에 바로 반영되지 않았습니다.',
      content: [
        {
          type: 'prose',
          paragraphs: [
            '통합 검색은 프로젝트, 개발자, 카테고리, 스킬을 함께 조회하는 기능이었습니다.',
            '초기에는 같은 검색 조건에서도 조회와 결과 조합을 다시 수행했고,\n검색 결과를 재사용한 이후에는 데이터 변경이 기존 검색 결과에 바로 반영되지 않는 문제를 확인했습니다.',
          ],
        },
        {
          type: 'tabs',
          tabs: [
            {
              id: 'before-cache',
              label: '반복 검색',
              title: '같은 검색 조건에서도 검색 대상 조회와 결과 조합을 다시 수행하는 문제가 있었습니다.',
              diagrams: [
                {
                  type: 'sequence',
                  density: 'compact',
                  connectorTone: 'subtle',
                  layout: 'deck',
                  label: '기존 통합 검색 처리 흐름',
                  steps: [
                    {
                      title: '검색 요청',
                      text: '사용자가 통합 검색 요청 전달',
                    },
                    {
                      title: '통합 검색 실행',
                      text: '전달된 검색 조건으로 통합 검색 로직 수행',
                    },
                    {
                      title: '검색 대상 조회',
                      text: '프로젝트\n개발자\n카테고리\n기술스택',
                    },
                    {
                      title: '결과 조합',
                      text: '각 검색 대상의 결과를 하나의 응답으로 구성',
                    },
                    {
                      title: '응답 반환',
                      text: '조합된 통합 검색 결과를 사용자에게 반환',
                    },
                  ],
                },
              ],
              subsection: {
                title: '',
                paragraphs: [],
                callout: '이전 검색 결과를 재사용하는 구조가 없어, 동일 조건의 반복 요청에서도 검색 대상 조회와 결과 조합 과정을 다시 수행하는 문제가 있었습니다.',
              },
            },
            {
              id: 'after-cache',
              label: '결과 최신성',
              title: '데이터가 변경된 뒤에도 이전 검색 결과가 그대로 반환되는 문제가 발생했습니다.',
              text: '기존 통합 검색 결과가 Cache에 저장된 뒤, 신규 개발자 회원가입으로 개발자와 기술스택 정보가 저장되었습니다.\n이후 이전과 동일한 조건으로 다시 검색했을 때 기존 Cache 결과가 반환되어 신규 개발자 정보가 통합 검색 결과에 바로 나타나지 않았습니다.',
              flow: [
                {
                  title: '기존 통합 검색 수행',
                  text: '동일 검색 조건의 결과가 Cache에 저장됨',
                },
                {
                  title: '신규 개발자 회원가입',
                  text: '개발자와 기술스택 정보가 함께 저장되어 원천 데이터 변경',
                },
                {
                  title: '이전과 동일한 조건으로 다시 검색',
                  text: '같은 검색 조건으로 다시 요청',
                },
                {
                  title: '데이터 변경 전 Cache 결과 반환',
                  text: '기존에 저장되어 있던 검색 결과 반환',
                },
                {
                  title: '신규 개발자 정보 미반영',
                  text: '신규 개발자가 통합 검색 결과에 나타나지 않음',
                },
              ],
              cards: {
                label: '문제의 본질',
                columns: 2,
                items: [
                  {
                    label: '원천 데이터 변경',
                    text: '신규 개발자 회원가입으로 개발자와 기술스택 관련 데이터가 변경됐습니다.',
                  },
                  {
                    label: '기존 검색 결과 유지',
                    text: '동일 조건에서는 데이터 변경 전에 저장된 검색 결과가 반환됐습니다.',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      number: '03',
      id: 'search-cache',
      title: 'Redis Cache Design',
      navTitle: '검색 캐시 설계',
      navSubtitle: 'Cache-Aside와 Key · TTL',
      lead: '검색 조건별로 캐시 키를 구성하고,\nCache Miss일 때만 실제 통합 검색을 수행했습니다.',
      content: [
        {
          type: 'prose',
          paragraphs: [
            '반복 검색 요청에서는 Redis Cache를 먼저 확인하도록 구성했습니다.\n동일한 keyword라도 page와 size가 달라지면 반환되는 검색 결과 범위가 달라지므로, 캐시 키를 keyword / page / size 조합으로 구성했습니다.',
          ],
        },
        {
          type: 'subsection',
          title: '구현 범위',
          text: '초기 QueryDSL 기반 통합 검색 구현과 Cache 적용·검증을 담당했습니다. 이후 팀의 인덱스 최적화 과정에서 일부 검색 방식이 FullText/ngram 기반으로 변경되었습니다.',
        },
        {
          type: 'tabs',
          tabs: [
            {
              id: 'cache-structure',
              label: '캐시 구조 선택',
              title: '반복 검색 결과를 재사용하기 위해 Cache 구조를 단계적으로 전환했습니다.',
              flow: [
                {
                  title: '캐시 미적용 초기 구조',
                  text: '같은 검색 조건이 반복되어도 매번 실제 통합 검색 로직과 조회 과정을 다시 수행했습니다.',
                },
                {
                  title: 'Caffeine Local Cache',
                  text: '초기에는 애플리케이션 내부 Local Cache로 반복 검색 결과를 재사용하는 구조를 적용했습니다.',
                },
                {
                  title: 'Redis Cache',
                  text: '여러 인스턴스로 확장할 경우 Local Cache가 인스턴스별로 분리될 수 있는 구조를 고려해 공유 Cache로 사용할 수 있는 Redis Cache로 전환했습니다.',
                  tone: 'primary',
                },
              ],
              supplementalCards: {
                label: 'Redis 선택 이유',
                columns: 2,
                items: [
                  {
                    label: 'Local Cache의 한계',
                    text: 'Local Cache는 애플리케이션 인스턴스 내부에 존재하므로,\n인스턴스가 여러 개가 되면 캐시가 서로 분리될 수 있습니다.',
                  },
                  {
                    label: 'Redis 선택',
                    text: '검색 결과를 공유할 수 있는 외부 Cache 구조가 필요해 Redis를 선택했습니다.',
                  },
                ],
              },
            },
            {
              id: 'cache-aside-flow',
              label: 'Cache-Aside 조회 흐름',
              title: '검색 요청에서 Redis Cache를 먼저 확인하는 흐름으로 구성했습니다.',
              flow: [
                {
                  title: '검색 요청',
                },
                {
                  title: '캐시 키 생성',
                },
                {
                  title: 'Redis Cache 조회',
                },
              ],
              cards: {
                label: 'Cache 조회 결과',
                columns: 2,
                items: [
                  {
                    label: 'Cache Hit',
                    text: 'Redis에 저장된 검색 결과를 반환하고, 실제 통합 검색 로직은 실행하지 않습니다.',
                  },
                  {
                    label: 'Cache Miss',
                    text: '실제 통합 검색 로직을 실행하고, 생성된 검색 결과를 Redis에 저장한 뒤 응답합니다.',
                    tone: 'primary',
                  },
                ],
              },
              supplementalCards: {
                label: 'Cache-Aside를 선택한 이유',
                columns: 2,
                items: [
                  {
                    label: '반복 검색 결과 재사용',
                    text: '통합 검색에서는 같은 검색 조건이 반복될 수 있었고, 여러 검색 대상을 조합한 결과를 Cache에서 먼저 확인해 기존 결과를 재사용할 수 있었습니다.',
                  },
                  {
                    label: '구현 기준',
                    text: 'Spring Cache의 @Cacheable을 적용해 Cache Hit이면 저장된 결과를 반환하고, Cache Miss일 때 실제 통합 검색을 수행하도록 구성했습니다.',
                  },
                ],
              },
            },
            {
              id: 'cache-key-ttl',
              label: '캐시 키 · TTL',
              title: '검색 결과를 요청 조건별로 구분하고 5분 동안 유지했습니다.',
              cards: {
                label: '캐시 키 정책',
                columns: 4,
                items: [
                  {
                    label: '캐시 대상',
                    text: '프로젝트, 카테고리, 기술스택, 개발자 정보를 포함한 통합 검색 결과',
                  },
                  {
                    label: '캐시 키 기준',
                    text: 'keyword / page / size\nKey Generator 형식: v2:{keyword}:{page}:{size}',
                    tone: 'primary',
                  },
                  {
                    label: 'keyword만으로 부족한 이유',
                    text: '같은 keyword라도 page와 size가 다르면 반환되는 검색 결과 범위가 달라집니다.',
                  },
                  {
                    label: 'TTL',
                    text: '검색 결과 Cache에 5분 TTL을 적용했습니다.',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      number: '04',
      id: 'cache-consistency',
      title: 'Cache Consistency Design',
      navTitle: '캐시 정합성',
      navSubtitle: '데이터 변경과 캐시 무효화',
      lead: '검색 결과에 영향을 주는 데이터가 변경되면\n검색 캐시를 무효화하고,\n다음 검색부터 최신 결과를 조회하도록 했습니다.',
      content: [
        {
          type: 'prose',
          paragraphs: [
            '통합 검색 결과는 keyword / page / size 조합별로 Redis 캐시에 저장됩니다. 하나의 데이터 변경이 여러 검색어와 페이지 조합에 영향을 줄 수 있어,\n변경된 데이터가 포함된 캐시 키를 변경 시점에 모두 역추적하기는 어려웠습니다.',
            '현재 구조에서는 검색 결과 최신성을 우선해, 검색 결과에 영향을 주는 주요 데이터 변경 경로에서 Spring Cache의 @CacheEvict와 RedisCacheManager를 이용해 globalSearch Cache를 전체 무효화했습니다.',
          ],
        },
        {
          type: 'callout',
          label: '검색 결과 최신성 기준',
          text: '데이터가 변경된 이후에는 변경 전 검색 결과를 재사용하지 않고, 다음 검색 요청에서 최신 데이터를 기준으로 실제 통합 검색을 수행하는 것을 캐시 정합성의 기준으로 삼았습니다.',
        },
        {
          type: 'tabs',
          tabs: [
            {
              id: 'all-entries',
              label: '무효화 결정',
              title: '검색 결과에 영향을 주는 데이터 변경 경로에서는\n검색 결과 캐시 전체 무효화를 선택했습니다.',
              text: '변경된 데이터가 포함된 모든 검색 캐시 키를 역추적하려면 별도의 키 매핑 구조가 필요했습니다. 현재 구조에서는 선택 삭제의 복잡도를 늘리기보다 검색 결과의 최신성을 우선했습니다.\n\n검색 결과에 영향을 주는 주요 데이터 변경 경로에 @CacheEvict를 적용하고, allEntries = true를 사용해 globalSearch 검색 결과 캐시를 전체 무효화했습니다.',
              cards: {
                columns: 2,
                items: [
                  {
                    label: '선택 삭제의 한계',
                    text: '검색 결과는 keyword / page / size 조합별로 저장됩니다. 하나의 데이터 변경이 어떤 검색어와 페이지 조합에 포함되어 있는지 역추적하려면 별도의 캐시 키 매핑 구조가 필요했습니다.',
                  },
                  {
                    label: '@CacheEvict 적용',
                    text: 'Spring Cache의 @CacheEvict와 RedisCacheManager를 이용해 별도의 Redis 키 삭제 코드를 직접 작성하지 않고, globalSearch 검색 결과 캐시를 선언적으로 무효화했습니다.',
                    tone: 'primary',
                  },
                  {
                    label: 'allEntries = true',
                    text: '변경된 데이터가 포함된 개별 캐시 키를 추적하지 않고, globalSearch 캐시 영역에 저장된 검색 결과 엔트리를 전체 제거했습니다.',
                  },
                  {
                    label: '수용한 트레이드오프',
                    text: '전체 무효화 직후 첫 검색 요청은 Cache Miss로 실제 통합 검색 로직을 다시 수행합니다. 일부 Cache Miss 증가를 수용하는 대신, 변경 이전 검색 결과가 사용자에게 계속 반환되지 않는 것을 우선했습니다.',
                  },
                ],
              },
              callout: '선택 결과\n변경 직후 첫 검색 요청은 Cache Miss로\n실제 통합 검색 로직을 다시 수행합니다.\n\n대신 변경 이전 검색 결과가 계속 반환되는 것을 방지하고,\n다음 검색부터는 최신 결과가 저장된 Redis 캐시를 재사용하도록 구성했습니다.',
              calloutTone: 'soft',
            },
            {
              id: 'change-paths',
              label: '무효화 흐름',
              title: '데이터 변경 이후 첫 검색 요청에서 최신 결과를 다시 적재합니다.',
              text: '검색 캐시를 제거한 뒤에는 다음 검색 요청이 Cache Miss로 이어집니다.\n이 요청에서 최신 데이터를 기준으로 실제 통합 검색 로직을 실행해 Redis에 저장하고, 이후 동일 조건의 검색부터는 갱신된 캐시를 재사용합니다.',
              cards: {
                columns: 3,
                items: [
                  {
                    label: '데이터 변경',
                    text: '검색 결과에 영향을 주는 주요 데이터 변경 경로에서 변경이 발생합니다.',
                  },
                  {
                    label: '캐시 무효화',
                    text: '@CacheEvict(allEntries = true)가 실행되고, RedisCacheManager가 관리하는 globalSearch 검색 결과 캐시가 무효화됩니다.',
                    tone: 'primary',
                  },
                  {
                    label: 'Cache Miss',
                    text: '다음 검색 요청에서는 기존 검색 결과 캐시가 없으므로 실제 검색 흐름으로 이어집니다.',
                  },
                  {
                    label: '최신 결과 구성',
                    text: '최신 데이터를 기준으로 실제 통합 검색 로직을 실행합니다.',
                  },
                  {
                    label: 'Redis 캐시 재적재',
                    text: '조회한 최신 검색 결과를 Redis 캐시에 다시 저장합니다.',
                    tone: 'primary',
                  },
                  {
                    label: '이후 요청',
                    text: '이후 동일한 검색 조건의 요청은 최신 결과가 저장된 Redis 캐시에서 응답합니다.',
                  },
                ],
              },
              callout: '결과\n데이터 변경 전 검색 결과가 계속 반환되는 문제를 방지하고,\n이후 요청부터 최신 검색 결과를 캐시로 재사용하도록 구성했습니다.',
              calloutTone: 'soft',
            },
          ],
        },
      ],
    },
    {
      number: '05',
      id: 'result',
      title: 'k6 Performance Verification',
      navTitle: '성능 검증',
      navSubtitle: 'k6 캐시 적용 전 · 후 비교',
      lead: '최대 100 VU까지 증가시키는 동일한 k6 시나리오로 캐시 미적용 v1과 Redis Cache 적용 v2를 비교했습니다.',
      content: [
        {
          type: 'prose',
          paragraphs: [
            '검증의 목적은 같은 조건에서 캐시 미적용 v1과 Redis Cache 적용 v2의 응답 시간과 처리량이 어떻게 달라졌는지 확인하는 것이었습니다.',
            '비교는 Local Docker 환경에서 projects 50,009건 데이터를 기준으로 진행했고, k6 Ramp-up 시나리오에서 최대 100 VU까지 증가시키며 2분 30초 동안 실행했습니다.\n요청 수는 고정값이 아니라, 동일한 실행 시간 동안 완료된 요청 건수입니다.',
            '성능 비교는 캐시 미적용 V1과 Redis Cache 적용 V2가 분리되어 있던 당시 구현을 기준으로 수행했습니다.\n이후 팀 리팩토링 및 인덱스 최적화 과정에서 최종 검색 구현 일부가 변경되었습니다.',
          ],
        },
        {
          type: 'tabs',
          tabs: [
            {
              id: 'k6-v1',
              label: 'v1 캐시 미적용',
              title: 'v1은 반복 검색 요청이 매번 실제 검색 흐름으로 이어졌습니다.',
              text: '캐시를 적용하지 않은 기준 결과입니다. 같은 검색 조건의 요청도 매번 실제 검색 흐름으로 이어졌고, 평균 응답 시간과 p95가 초 단위로 측정됐습니다.',
              callout: 'v1 결과는 Redis Cache 적용 전 기준선입니다. 이후 v2와 비교하기 위해 동일한 최대 100 VU 조건으로 실행했습니다.',
              calloutTone: 'soft',
              supportCards: [
                {
                  title: 'v1 캐시 미적용 k6 실행 결과',
                  text: 'TOTAL RESULTS와 HTTP 지표에서 평균 응답 시간, p95, 처리량, 실패율을 확인했습니다.',
                  image: {
                    src: '/readys7-images/readys7-k6-v1-no-cache.png',
                    alt: 'Ready’s7 v1 캐시 미적용 k6 테스트 결과',
                  },
                  items: [
                    { label: '평균 응답 시간', value: '1.94s' },
                    { label: 'p95', value: '3.56s' },
                    { label: '처리량', value: '16.19 req/s' },
                    { label: '요청 수', value: '2,436' },
                    { label: '실패율', value: '0%' },
                    { label: '최대 VU', value: '100' },
                  ],
                },
              ],
            },
            {
              id: 'k6-v2',
              label: 'v2 Redis Cache 적용',
              title: 'v2는 반복 검색 요청을 Redis Cache에서 응답하도록 적용했습니다.',
              text: 'Redis Cache 적용 후의 비교 결과입니다. Cache Hit 구간에서는 실제 검색 로직을 거치지 않고 캐시된 검색 결과를 반환하도록 구성했습니다.',
              callout: '동일한 최대 100 VU 조건에서 실패율 0%를 유지했고, 평균 응답 시간과 p95는 ms 단위로 측정됐습니다.',
              calloutTone: 'soft',
              supportCards: [
                {
                  title: 'v2 Redis Cache 적용 k6 실행 결과',
                  text: 'Redis Cache 적용 후 동일한 최대 100 VU 조건에서 측정한 결과입니다.',
                  image: {
                    src: '/readys7-images/readys7-k6-v2-redis-cache.png',
                    alt: 'Ready’s7 v2 Redis Cache 적용 k6 테스트 결과',
                  },
                  items: [
                    { label: '평균 응답 시간', value: '3.73ms' },
                    { label: 'p95', value: '6.39ms' },
                    { label: '처리량', value: '46.68 req/s' },
                    { label: '요청 수', value: '7,046' },
                    { label: '실패율', value: '0%' },
                    { label: '최대 VU', value: '100' },
                  ],
                },
              ],
            },
          ],
        },
      ],
    },
    {
      number: '06',
      id: 'demo',
      title: '시연 영상',
      navTitle: '시연 영상',
      navSubtitle: '주요 기능 동작 확인',
      lead: 'Ready’s7의 주요 기능과 사용자 흐름을 실제 화면에서 확인할 수 있습니다.',
      content: [
        {
          type: 'prose',
          paragraphs: [
            '프로젝트 등록과 탐색, 제안서 제출·확인, 채팅과 리뷰까지 구현된 주요 흐름을 시연합니다.',
          ],
        },
        {
          type: 'video',
          src: '/readys7-demo.mp4',
          mimeType: 'video/mp4',
          title: 'Ready’s7 주요 사용 흐름 시연',
          description: '프로젝트 등록과 탐색, 제안서 제출·확인, 채팅과 리뷰로 이어지는 흐름입니다.',
        },
      ],
    },
  ],
};

